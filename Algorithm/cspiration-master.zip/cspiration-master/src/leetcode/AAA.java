package leetcode;

import java.util.*;

/**
 * Project Name : Leetcode
 * Package Name : leetcode
 * File Name : AAA
 * Creator : Edward
 * Date : Aug, 2017
 * Description : TODO
 */
public class AAA {

    public static int helper(int a) {
        a = 50;
        return a;
    }

    public static void main(String[] args) {

    }
}
