package leetcode;

/**
 * Project Name : Leetcode
 * Package Name : leetcode
 * File Name : TreeLinkNode
 * Creator : Edward
 * Date : Oct, 2017
 * Description : TODO
 */
public class TreeLinkNode {
    int val;
    TreeLinkNode left, right, next;
    TreeLinkNode(int x) {
        val = x;
    }
}
