package leetcode;

/**
 * Project Name : Leetcode
 * Package Name : leetcode
 * File Name : Interval
 * Creator : Edward
 * Date : Oct, 2017
 * Description : TODO
 */
public class Interval {
    int start;
    int end;
    Interval() {
        start = 0;
        end = 0;
    }
    Interval(int s, int e) {
        start = s;
        end = e;
    }
}
