package leetcode;

/**
 * Created by Edward on 25/07/2017.
 */
public class ListNode {

    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
        next = null;
    }
}
