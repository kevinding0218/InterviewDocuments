package leetcode;

/**
 * Project Name : Leetcode
 * Package Name : leetcode
 * File Name : Point
 * Creator : Edward
 * Date : Aug, 2017
 * Description : TODO
 */
public class Point {
    int x;
    int y;
    Point() {
        x = 0;
        y = 0;
    }
    Point(int a, int b) {
        x = a;
        y = b;
    }
}
